<?php
// Database Connection Parameters
$db_host="db479694104.db.1and1.com";
$db_name="db479694104";
$username="dbo479694104";
$password="Sigmachi88";

$db_con=mysql_connect($db_host,$username,$password);
$connection_string=mysql_select_db($db_name);

// Connection
//mysql_connect($db_host,$username,$password);
//mysql_select_db($db_name);
?>