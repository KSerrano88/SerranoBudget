<?php
/*********************************************************************************
	11/26/2010
	Delete most recent record added to TRANSACTIONS table.
*********************************************************************************/

//Include DB login config and header files
include_once('../DatabaseConfig/db_config.php');
include_once('../Header_Footer/header.html');


//Subquery to select last record added to DB
$sql_maxid = "SELECT max(id_transactions) as maxid
			  FROM transactions";
//Store query result in array			  
$result_maxid = mysql_query($sql_maxid);    
//Fetch Array values
$row = mysql_fetch_assoc($result_maxid); 

//Query to DELETE last record added to DB
$sql_delete = "DELETE FROM transactions
			   WHERE id_transactions = $row[maxid]";		

//Execute Delete statement			   
$result_delete = mysql_query($sql_delete, $db_con) or die(print'<h3>Transaction not deleted</h3>'.mysql_error());


mysql_close();
?>

<h3>Last Transaction Deleted</h3>
<a href="transactions.php">Add another transaction...</a> <br /><br />


<?php
include_once('../Header_Footer/footer.html');
?>